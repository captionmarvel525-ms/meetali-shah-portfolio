// ============================================
// 1. MOBILE MENU TOGGLE
// On small screens the nav links are hidden until
// the hamburger button is clicked.
// ============================================
const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');

navToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', isOpen);
});

// Close the mobile menu automatically once a link is tapped,
// so the menu doesn't stay open after navigating.
navLinks.querySelectorAll('.nav-link').forEach((link) => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
  });
});

// ============================================
// 2. HERO ENTRANCE ANIMATION
// This runs once, right after the page loads — a single
// deliberate reveal rather than every section animating
// in as you scroll (which tends to look repetitive).
// ============================================
window.addEventListener('DOMContentLoaded', () => {
  const hero = document.querySelector('.hero');
  // Small delay so the browser has painted the page first
  setTimeout(() => hero.classList.add('in-view'), 100);
});

// ============================================
// 3. ACTIVE NAV LINK ON SCROLL
// As you scroll past each section, its matching nav link
// is highlighted in the accent color. This uses the
// IntersectionObserver API, which watches elements and
// tells us when they enter/leave the visible part of the
// screen — much more efficient than checking scroll
// position manually.
// ============================================
const sections = document.querySelectorAll('main section[id]');

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        const matchingLink = document.querySelector(`.nav-link[href="#${id}"]`);

        // Remove "active" from every link, then add it back
        // only to the one matching the section in view.
        document.querySelectorAll('.nav-link').forEach((link) => {
          link.classList.remove('active');
        });

        if (matchingLink) {
          matchingLink.classList.add('active');
        }
      }
    });
  },
  {
    // A section counts as "in view" once it crosses the
    // vertical middle of the screen.
    rootMargin: '-50% 0px -50% 0px',
  }
);

sections.forEach((section) => observer.observe(section));

// ============================================
// 4. SCROLL-IN ANIMATION FOR SECTIONS
// Each section (About, Skills, Projects, Achievements,
// Contact) fades and slides in the first time it enters
// the screen. Uses the same IntersectionObserver approach
// as the active-nav-link logic above, but only needs to
// fire once per section, so we unobserve after it reveals.
// ============================================
const revealObserver = new IntersectionObserver(
  (entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        obs.unobserve(entry.target);
      }
    });
  },
  {
    threshold: 0.15,
  }
);

document.querySelectorAll('main .section').forEach((section) => {
  revealObserver.observe(section);
});
